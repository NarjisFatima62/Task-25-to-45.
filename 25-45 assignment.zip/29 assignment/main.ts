//Question No.29
// Favorite Fruit: Make a array of your favorite fruits, and then write a series of independent if statements that check for certain fruits in your array.
// • Make a array of your three favorite fruits and call it favorite_fruits.

// • Write five if statements. Each should check whether a certain kind of fruit is in your array. If the fruit is in your array, the if block should print a statement, such as You really like bananas!

//Answer:

let favorite_fruits = ["Banana", "Grapes", "Pineapple"];

if (favorite_fruits. includes("Banana")) {
    console.log("you really like Banana!");
}

if (favorite_fruits. includes("Grapes")) {
    console.log("you really like Grapes!");
}

if (favorite_fruits. includes("Pineapple")) {
    console.log("you really like Pineapple!");
}

if (favorite_fruits. includes("Orange")) {
    console.log("you really like Orange!");
}

if (favorite_fruits. includes("Mango")) {
    console.log("you really like Mango!");
}